
var Board = function(size){
    this.size = size;
    this.boxes = Array(size);
    for(var i=0; i<this.size;i++){
        this.boxes[i] = new Box(i);
    }
}

Board.prototype.render = function(){
    var domBoard = document.querySelector("#board");
    var nbRows = Math.sqrt(this.boxes.length);
    var domRow;
    var i, j;

    //Clear
    while(domBoard.firstChild){
        domBoard.removeChild(domBoard.firstChild);
    }

    for(i=0; i<nbRows; i++){
        domRow = document.createElement("div");
        domRow.className = "board-row";
        domBoard.appendChild(domRow);

        for(j=0; j<nbRows; j++){
            domRow.appendChild( this.boxes[i*nbRows + j].getNode() );
        }
    }
}

Board.prototype.changeBox = function(boxId){
    if(this.boxes[boxId])
    {
        this.boxes[boxId].changeValue();
        this.render();
    }
};


Board.prototype.clear = function(){
    for(var i in this.boxes){
        this.boxes[i].value = '?';
    }
    board.render();
};


var Box = function(idBox){
    this.idBox = idBox;
    this.value = "?";
}

Box.prototype.changeValue = function(){
    switch(this.value){
        case "?": this.value = "X"; break;
        case "X": this.value = "O"; break;
        case "O": this.value = "X"; break;
    }
}

Box.prototype.getNode = function(){
    var domBox = document.createElement("button");
    domBox.className = "square";
    domBox.id = this.idBox;
    domBox.innerHTML = this.value;
    
    domBox.addEventListener("click", function(){board.changeBox(this.id)});
    //Faire des recherches sur comment utiliser l'évènement click (méthode addEventListener de Node)

    return domBox;
}
